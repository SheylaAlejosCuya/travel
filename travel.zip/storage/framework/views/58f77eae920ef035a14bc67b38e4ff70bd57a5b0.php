<?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
	@charset  "utf-8";
/* CSS Document */
.responsive-iframe {
  position: relative;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  width: 100%;
  height: 900px;
}
.buscaador{
      height: 1000px;
    }
     .subtitulo{
      height: 1500px;
    }
@media(max-width:1000px) {
    #nosotrosText,
    #homeText,
    #contactoText {
        border-radius: 15px;
        color: white;
        margin-bottom: 1.5px;
        padding-left: 5%;
    }
    .buscaador{
      height: 1500px;
    }
     .subtitulo{
      height: 1500px;
    }
}
</style>
<section class="buscaador" >
    <div class="subtitulo"  >
      <h1><b> Encuentra cientos de vuelos a la vez</b></h1>
      <hr id="subtibarra"> 
      <iframe src="https://startravelperu.clickandbook.com" class="responsive-iframe" frameborder="0"></iframe>
      
      </div>      
  </section>

   
 

  <?php echo $__env->make('partials.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<script type="text/javascript"> 


  $(document).on('click', '.btn_modal_mostrar', function() {

      $('#modal_viajes').modal('show');
      console.log($(this).data('imagen'));
      $('#title_modal').text($(this).data('title'));
      $('#title_modale').val($(this).data('title'));
      $('#descripcion').text($(this).data('descripcion'));
      $('#imagen').attr('src', $(this).data('image'));
  });

 
</script>

<?php /**PATH C:\Users\freda\Documents\Development\Php\travel\resources\views/travel.blade.php ENDPATH**/ ?>