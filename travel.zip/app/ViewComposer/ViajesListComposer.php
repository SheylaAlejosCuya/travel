<?php
namespace App\Http\ViewComposer;
use Illuminate\View\View;
use App\Models\Viaje;
class ViajesListComposer{
    
    public function compose(View $view){
     }
}